# GraphQL API Automation
This project is a sample project which demonstrate GraphQL API automation with Rest Assured and Java

Precondtion
-----------
* Set up Java 8 in the machine and set the path variables accordingly with the OS (Linux/Ubuntu/Mac)

Steps
-----

* This example is created using IntelijIdea IDE. Once you clone the project navigate to the File-> project structure and set the Project SDK as java 1.8 from your PC 
* Install maven and  set up the path in OS and update the intelijidea maven settings
* Add Lombok pluign in to the intelijidea by navigating to the File -> Settings -> Plugins and search "Lombok"

