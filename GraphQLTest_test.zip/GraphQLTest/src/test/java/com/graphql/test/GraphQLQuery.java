package com.graphql.test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.io.payload.PayloadAPI;
import com.io.pojo.GraphQLPojo;
import com.io.pojo.QueryPojoVariable;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class GraphQLQuery {
	
/**
 * @Description This method is designed to validate all films title.
 * @author Jagannath Swain
 * @Date 14/8/2022
*/
	@Test
	public void graphQLTest(){
		try {
			RestAssured.baseURI ="https://swapi-graphql.netlify.app";
			String query = "{\"query\":\"{\\n  allFilms {\\n    films {\\n      title\\n    }\\n  }\\n}\\n\",\"variables\":null}";
			
			given().log().all()
			.contentType("application/json")
			.body(query)
			.when().log().all()
			.post("/.netlify/functions/index")
			.then().log().all()	
			.assertThat()
			.statusCode(200)
			.and()
			.body("data.allFilms.films[0].title", equalTo("A New Hope"));
		}catch(Exception e) {
			System.out.println(e);
		}finally {
			System.out.println("Must executable code");
		}							
	}

/**
 * @Description This method is designed to validate space mission status.
 * @author Jagannath Swain
 * @Date 14/8/2022
*/
	@Test
	public void spaceDetails() {
		try {
			RestAssured.baseURI ="https://api.spacex.land";
			String query = "{\"query\":\"{\\n  ships {\\n    image\\n    missions {\\n      flight\\n      name\\n    }\\n  }\\n}\\n\",\"variables\":null}";
			
			given().log().all()
			.contentType("application/json")
			.body(query)
			.when().log().all()
			.post("/graphql")
			.then().log().all()	
			.assertThat()
			.statusCode(200);	
		}catch(Exception e) {
			System.out.println(e);
		}finally {
			System.out.println("Must executable code");
		}							
	}

/**
 * @Description This method is designed to validate space launch site.
 * @author Jagannath Swain
 * @Date 14/8/2022
*/
	@Test
	public void compAndLaunchDetails() {
		try {
			RestAssured.baseURI ="https://api.spacex.land";
			String query = "{\"query\":\"{\\n  company {\\n    ceo\\n    employees\\n  }\\n  launches {\\n    launch_site {\\n      site_id\\n      site_name\\n    }\\n  }\\n}\\n\",\"variables\":null}";
			
			given().log().all()
			.contentType("application/json")
			.body(query)
			.when().log().all()
			.post("/graphql")
			.then().log().all()	
			.assertThat()
			.statusCode(200)
			.and()
			.body("data.launches[0].launch_site.site_id", equalTo("ccafs_slc_40"));
		}catch(Exception e) {
			System.out.println(e);
		}finally {
			System.out.println("Must executable code");
		}						
	}

/**
 * @Description This method is designed to validate space launch status using data provider
 * @author Jagannath Swain
 * @Date 14/8/2022
*/
	@DataProvider
	public Object[][] getQueryData() {
		return new Object[][] {{10,2},
								};
	}
	
	@Test(dataProvider = "getQueryData")
	public void getLaunchesDetailsTest(int offset, int limit) {
		try {
			RestAssured.baseURI ="https://api.spacex.land";
			String query = "{\"query\":\"{\\n  company {\\n    ceo\\n  }\\n  launches(offset: "+offset+", limit: "+limit+") {\\n    id\\n    details\\n  }\\n}\\n\",\"variables\":null}";
			
			given().log().all()
			.contentType("application/json")
			.body(query)
			.when().log().all()
			.post("/graphql")
			.then().log().all()
			.assertThat()
			.statusCode(200);
		}catch(Exception e) {
			System.out.println(e);
		}finally {
			System.out.println("Must executable code");
		}					
	}

/**
 * @Description This method is designed to validate user details using POJO Class
 * @author Jagannath Swain
 * @Date 14/8/2022
*/
	@Test
	public void getAllUsers_WithPojoTest() {
		try {
			RestAssured.baseURI ="https://hasura.io";
			GraphQLPojo query = new GraphQLPojo();
			
			query.setQuery("query($limit:Int!){\r\n"
					+ "  users(limit: $limit) {\r\n"
					+ "    name\r\n"
					+ "  }\r\n"
					+ "}");
			
			QueryPojoVariable variable = new QueryPojoVariable();
			variable.setLimit(6);
			query.setVariables(variable);
			
			given().log().all()
			.contentType(ContentType.JSON)
			.header("Authorization", "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik9FWTJSVGM1UlVOR05qSXhSRUV5TURJNFFUWXdNekZETWtReU1EQXdSVUV4UVVRM05EazFNQSJ9.eyJodHRwczovL2hhc3VyYS5pby9qd3QvY2xhaW1zIjp7IngtaGFzdXJhLWRlZmF1bHQtcm9sZSI6InVzZXIiLCJ4LWhhc3VyYS1hbGxvd2VkLXJvbGVzIjpbInVzZXIiXSwieC1oYXN1cmEtdXNlci1pZCI6ImF1dGgwfDYyZjhiZWJlYWFmZWFjOGRmZmI2YjAzOCJ9LCJuaWNrbmFtZSI6ImphZ2FubmF0aDA2Nzk5IiwibmFtZSI6ImphZ2FubmF0aDA2Nzk5QGdtYWlsLmNvbSIsInBpY3R1cmUiOiJodHRwczovL3MuZ3JhdmF0YXIuY29tL2F2YXRhci9jNWY2MTQ5ZjgzMjQ2NDNlMTFhNjdhOGM3ZGMzZDljMT9zPTQ4MCZyPXBnJmQ9aHR0cHMlM0ElMkYlMkZjZG4uYXV0aDAuY29tJTJGYXZhdGFycyUyRmphLnBuZyIsInVwZGF0ZWRfYXQiOiIyMDIyLTA4LTE0VDA5OjIyOjA4LjUyOFoiLCJpc3MiOiJodHRwczovL2dyYXBocWwtdHV0b3JpYWxzLmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw2MmY4YmViZWFhZmVhYzhkZmZiNmIwMzgiLCJhdWQiOiJQMzhxbkZvMWxGQVFKcnprdW4tLXdFenFsalZOR2NXVyIsImlhdCI6MTY2MDQ2ODkzMCwiZXhwIjoxNjYwNTA0OTMwLCJhdF9oYXNoIjoiWXlwQkt2MkJxdllDc1lBVkpfTGw1ZyIsIm5vbmNlIjoifjhLZlMyMEFuYnI1RHRyaFpWLXBzN0pvd2JTWDFteEEifQ.QgAZRCv8n3d3q31JbtU0eaoPx1uOYqkqsDmHxTx3TkFOFJ6H1v3gZnB_KgGNw74Gl3dDxmpCxFqDSe8JYQ44MDZ_9yj6atQjs7gaTjrUzjahnyY6A4yKIlTB1fAbbzjuwmm1EnpyZvNlGe1QU9R4eFfP4azWGxEtVlsFl3v8F5d4rZoNrjOlnyztGJ6Clb88zISvrd1g_uY5V0xMyOVQh4suojo86u_my4QELMiT7zRo50Mhzqeno-NIJcR5csS5iYjavJskb800URDlX9llWVjbWmFn4CsZIZMSGihcbJHVAEnZ303rMmA9UXww-J5EHgnlIc5ZDwmDZgWsdJOPWQ")		
			.body(query)
		    .when().log().all()
			.post("/learn/graphql")
		    .then().log().all()
			.assertThat()
			.statusCode(200)
			.and()
			.body("data.users[0].name", equalTo("tui.glen"));	
		}catch (Exception e) {
			System.out.println(e);
		}finally {
			System.out.println("Must executable code");
		}					
	}

/**
 * @Description This method is designed to create mutation - Insert
 * @author Jagannath Swain
 * @Date 14/8/2022
*/
	@Test
	public void createMutation() {
		try {
			RestAssured.baseURI ="https://hasura.io/learn";
			String mutation = "{\"query\":\"mutation {\\n  insert_todos_one(object: {is_public: true, title: \\\"MyName\\\"}) {\\n    user {\\n      id\\n      name\\n    }\\n  }\\n}\\n\",\"variables\":null}";
			
			String response = given().log().all()
			.contentType("application/json")
			.header("Authorization", "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik9FWTJSVGM1UlVOR05qSXhSRUV5TURJNFFUWXdNekZETWtReU1EQXdSVUV4UVVRM05EazFNQSJ9.eyJodHRwczovL2hhc3VyYS5pby9qd3QvY2xhaW1zIjp7IngtaGFzdXJhLWRlZmF1bHQtcm9sZSI6InVzZXIiLCJ4LWhhc3VyYS1hbGxvd2VkLXJvbGVzIjpbInVzZXIiXSwieC1oYXN1cmEtdXNlci1pZCI6ImF1dGgwfDYyZjhiZWJlYWFmZWFjOGRmZmI2YjAzOCJ9LCJuaWNrbmFtZSI6ImphZ2FubmF0aDA2Nzk5IiwibmFtZSI6ImphZ2FubmF0aDA2Nzk5QGdtYWlsLmNvbSIsInBpY3R1cmUiOiJodHRwczovL3MuZ3JhdmF0YXIuY29tL2F2YXRhci9jNWY2MTQ5ZjgzMjQ2NDNlMTFhNjdhOGM3ZGMzZDljMT9zPTQ4MCZyPXBnJmQ9aHR0cHMlM0ElMkYlMkZjZG4uYXV0aDAuY29tJTJGYXZhdGFycyUyRmphLnBuZyIsInVwZGF0ZWRfYXQiOiIyMDIyLTA4LTE0VDA5OjIyOjA4LjUyOFoiLCJpc3MiOiJodHRwczovL2dyYXBocWwtdHV0b3JpYWxzLmF1dGgwLmNvbS8iLCJzdWIiOiJhdXRoMHw2MmY4YmViZWFhZmVhYzhkZmZiNmIwMzgiLCJhdWQiOiJQMzhxbkZvMWxGQVFKcnprdW4tLXdFenFsalZOR2NXVyIsImlhdCI6MTY2MDQ2ODkzMCwiZXhwIjoxNjYwNTA0OTMwLCJhdF9oYXNoIjoiWXlwQkt2MkJxdllDc1lBVkpfTGw1ZyIsIm5vbmNlIjoifjhLZlMyMEFuYnI1RHRyaFpWLXBzN0pvd2JTWDFteEEifQ.QgAZRCv8n3d3q31JbtU0eaoPx1uOYqkqsDmHxTx3TkFOFJ6H1v3gZnB_KgGNw74Gl3dDxmpCxFqDSe8JYQ44MDZ_9yj6atQjs7gaTjrUzjahnyY6A4yKIlTB1fAbbzjuwmm1EnpyZvNlGe1QU9R4eFfP4azWGxEtVlsFl3v8F5d4rZoNrjOlnyztGJ6Clb88zISvrd1g_uY5V0xMyOVQh4suojo86u_my4QELMiT7zRo50Mhzqeno-NIJcR5csS5iYjavJskb800URDlX9llWVjbWmFn4CsZIZMSGihcbJHVAEnZ303rMmA9UXww-J5EHgnlIc5ZDwmDZgWsdJOPWQ")
			.body(mutation)
			.when().log().all()
			.post("/graphql")
			.then().log().all()	
			.assertThat()
			.statusCode(200)
			.extract()
			.response()
			.asString();
			 System.out.println("Inserted data is "+ response);
		}catch(Exception e){
			System.out.println(e);	
		}finally {
			System.out.println("Must executable code");
		}						
	}

/**
 * @Description This method is designed to pass the payload from different package.
 * @author Jagannath Swain
 * @Date 14/8/2022
*/
	@Test
	public void passPayloadFromOutside() {
		try {
			RestAssured.baseURI ="https://api.spacex.land";
			String payload = PayloadAPI.getLaunchSiteAPI();
			
			String response = given().log().all()
			.contentType("application/json")			
			.body(payload)
			.when().log().all()
			.post("/graphql")
			.then().log().all()	
			.assertThat()
			.statusCode(200)
			.extract()
			.response()
			.asString();
			 System.out.println("Successfully payload passed "+ response);
		}catch(Exception e){
			e.printStackTrace();	
		}finally {
			System.out.println("Must executable code");
		}						
	}	
}